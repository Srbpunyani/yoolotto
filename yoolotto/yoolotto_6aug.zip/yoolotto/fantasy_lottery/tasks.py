from celery.task import Task
from celery.registry import tasks
from celery.task import PeriodicTask
import datetime
from datetime import timedelta
from django.db.models import F
#from yoolotto.second_chance.models import ResetCoins
import celery



        