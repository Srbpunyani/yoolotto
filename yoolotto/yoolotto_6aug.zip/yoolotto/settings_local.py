


DEBUG = True
PRODUCTION=False






#----------------------------------------------------------------------------
COUPON_MAIL_CC=['elmer@yoolotto.com','ali@yoolotto.com'] if PRODUCTION else ['irfan@spa-systems.com']
COUPON_REDEEM_DURATION=24*60 if PRODUCTION else 24*60 # duration must be in minutes
NOTIFICATIONS_SANDBOX=not PRODUCTION #set sandbox based on production 

ALLOWED_HOSTS = ["*"]
# POSTMARK_API_KEY = ""
# POSTMARK_SENDER = ""

ADMINS = (
    ('Yoolotto', 'irfan@spa-systems.com'),
)


MANAGERS = ADMINS

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql', # Add 'postgresql_psycopg2', 'mysql', 'sqlite3' or 'oracle'.
        'NAME': 'yoo_db',                      # Or path to database file if using sqlite3.
        # The followinettings are not used with sqlite3:
        'USER': 'root',
        'PASSWORD': 'root',
        'HOST': 'localhost',                      # Empty for localhost through domain sockets or '127.0.0.1' for localhost through TCP.
        'PORT': '3306',                      # Set to empty string for default.
    }
}

BASE_URL = "http://localhost:8000"

#DEFAULT_FROM_EMAIL = "prizes@yoolotto.com"
#EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'
#EMAIL_USE_TLS = True
#EMAIL_HOST = 'smtp.gmail.com'
#EMAIL_PORT = 587
#EMAIL_HOST_USER = 'yoolottocoupons@gmail.com'
#EMAIL_HOST_PASSWORD = 'Yoolotto@123'

DEFAULT_FROM_EMAIL = "prizes@yoolotto.com"
EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'
EMAIL_USE_TLS = True
EMAIL_HOST = 'smtp.gmail.com'
EMAIL_PORT = 587
EMAIL_HOST_USER = 'prizes@yoolotto.com'
EMAIL_HOST_PASSWORD = 'yoolotto@123'

