#VIDEO
VIDEO_DEFAULT_RESPONSE_TYPE="xml"
VIDEO_ADUNIT_REQUEST_URL_ANDROID="http://ox-d.yoolotto.com/v/1.0/av%s?auid=537150922%s" # must be fetch through pre_process_url() 
VIDEO_ADUNIT_REQUEST_URL_IPHONE="http://ox-d.yoolotto.com/v/1.0/av%s?auid=537156510%s" # must be fetch through pre_process_url()

VIDEO_ADUNIT_ID="537156510"
VIDEO_ADUNIT_DOMAIN="ox-d.yoolotto.com"
VIDEO_ADUNIT_URL="http://ox-d.yoolotto.com/v/1.0/av?auid=537156510"

#IMAGE
IMAGE_DEFAULT_RESPONSE_TYPE="json"
IMAGE_ADUNIT_DOMAIN="ox-d.yoolotto.com"#common for both android and iphone
IMAGE_ADUNIT_REQUEST_URL_ANDROID="http://ox-d.yoolotto.com/ma/1.0/ar%s?auid=537149030" # must be fetch through pre_process_url() 
IMAGE_ADUNIT_REQUEST_URL_IPHONE="http://ox-d.yoolotto.com/ma/1.0/ar%s?auid=537156506" # must be fetch through pre_process_url()

IMAGE_ADUNIT_ID_REAL_ANDROID="20043e66-e0ad-fff1-8123-2448be"
IMAGE_ADUNIT_ID_ANDROID="537149030"

IMAGE_ADUNIT_ID_REAL_IPHONE="20045b9a-e0ad-fff1-8123-2448be"
IMAGE_ADUNIT_ID_IPHONE="537156506"


#NOTIFICATION
