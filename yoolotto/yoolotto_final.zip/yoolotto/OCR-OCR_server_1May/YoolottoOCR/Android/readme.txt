http://www.tag-games.com/2012/06/05/native-android-debugging-in-eclipse/
