#ifndef _POSTPROCESSING_H
#define _POSTPROCESSING_H

int getLine(char* results, int n, int* iStart, int* iStop);

#endif
